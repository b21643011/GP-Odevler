﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class DataUnit
{
    public string ad;
    public string soyad;
    public string metin;
    public DataUnit() {}
    public DataUnit(string birAd, string birSoyad, string birMetin) {
        this.ad = birAd;
        this.soyad = birSoyad;
        this.metin = birMetin;
    }

}