﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UIManagerFinal: MonoBehaviour
{
    public InputField ad_InputField, soyad_InputField, metin_InputField;
    public Button gonder_Button,kaydet_Button;
    public Text adText, soyadText, metinText;
    public GameObject girdiPrefabi, kayitYuklePaneli;
    public Transform bilgiKontrolPanel;
    public Dropdown kayitlar_Dropdown;
    public List<DataUnit> gunlukVerileri = new List<DataUnit>();
    private List<string> isimler = new List<string>();
    public List<DataUnit> geciciVeriler;
    private void Start() {
        AcilirMenuyuGetirVeyaGuncelle();
        kaydet_Button.onClick.AddListener(BilgileriKaydet);
        gonder_Button.onClick.AddListener(BilgileriGonder);
    }

    private void AcilirMenuyuGetirVeyaGuncelle()
    {
        VerileriDisktenGeriYukle(); // Diskteki varolan verileri listeye aktar.
        kayitlar_Dropdown.ClearOptions();
        
        geciciVeriler = new List<DataUnit>(gunlukVerileri);

        for (int i = 0; i < geciciVeriler.Count; i++)
        {
            isimler.Add(geciciVeriler[i].ad + " " + geciciVeriler[i].soyad);
        }

        kayitlar_Dropdown.AddOptions(isimler);
        isimler.Clear();
    }

    public void AcilirMenuKontrol(int index)
    {
        adText.text = gunlukVerileri[index].ad;
        soyadText.text = gunlukVerileri[index].soyad;
        metinText.text = gunlukVerileri[index].metin;
    }

    private void VerileriDisktenGeriYukle() {
        GetComponent<DataManager1>().Load();
    }
    private void VerileriDiskeKaydet() {
        GetComponent<DataManager1>().Save();
    }
    public void BilgileriEkranaYukle(DataUnit birDataUnit, bool istekYeniGirdidenGeliyor=true) {
        bilgiKontrolPanel.gameObject.SetActive(true);
        kaydet_Button.gameObject.SetActive(istekYeniGirdidenGeliyor ? true : false);
        adText.text = birDataUnit.ad;
        soyadText.text = birDataUnit.soyad;
        metinText.text = birDataUnit.metin;
    }

    private void BilgileriGonder() {
        DataUnit yeniGirdiBirimi = new DataUnit(ad_InputField.text, soyad_InputField.text, metin_InputField.text);
        BilgileriEkranaYukle(yeniGirdiBirimi);
    }

    private void BilgileriKaydet() {
        DataUnit yeniVeriGirdisi = new DataUnit(adText.text, soyadText.text, metinText.text);
        gunlukVerileri.Add(yeniVeriGirdisi);
        VerileriDiskeKaydet();
        geciciVeriler.Clear();
        AcilirMenuyuGetirVeyaGuncelle();
    }
}