﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public class DataManager1: MonoBehaviour
{
    public void Save() {
        UIManagerFinal myUIManager = GetComponent<UIManagerFinal>();
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/gunluk.gp");
        bf.Serialize(file, myUIManager.gunlukVerileri);
        file.Close();

        Debug.Log("Bilgiler kaydedildi");
    }

    public void Load() {
        if (File.Exists(Application.persistentDataPath + "/gunluk.gp")) {
            UIManagerFinal myUIManager = GetComponent<UIManagerFinal>();
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(Application.persistentDataPath + "/gunluk.gp", FileMode.Open);
            
            myUIManager.gunlukVerileri = (List<DataUnit>)bf.Deserialize(file);
            file.Close();

            Debug.Log("Günlük bilgileri yüklendi");
        } else {
            Debug.Log("Günlük dosyası bulunamadı");
        }
    }
}
