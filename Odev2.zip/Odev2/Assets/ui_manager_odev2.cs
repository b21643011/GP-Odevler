﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ui_manager_odev2 : MonoBehaviour
{

        public InputField yazimAlani_InputField;
        public Text goruntulemeAlani_Text;
        public Button gonder_Button, sifirla_Button, kaydet_Button;
        public List<string> gunlukVerileri = new List<string>();
        public void BilgileriGonder()
                {
                    string goruntulenecekVeri = yazimAlani_InputField.text;
                    goruntulemeAlani_Text.text += goruntulenecekVeri +"  ";
                }
        public void BilgileriKaydet()
                {
                    string goruntulenecekVeri = goruntulemeAlani_Text.text;
                    gunlukVerileri.Add(goruntulenecekVeri);
                }

        public void BilgileriSifirla()
                {
                    goruntulemeAlani_Text.text = "";
                }
}

