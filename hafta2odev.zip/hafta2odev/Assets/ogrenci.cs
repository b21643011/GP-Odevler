﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ogrenci : MonoBehaviour
{

    public Button ogrenci1Button; //input olarak alınacak bir değişken oluşturduk.    public Button doktor1Button, doktor2Button, doktor3Button; gibi de yazılabilir.
    public Button ogrenci2Button;
    public Button ogrenci3Button;

    public Text ders1_Text;
    public Text ders2_Text;
    public Text ders3_Text;
    public Text ders4_Text;
    public Text ders5_Text;

    //fonksiyonlar büyük harfle başlar.
      private void Start()
      {
          ogrenci1Button.onClick.AddListener(ogrenciBilgisiniYazdir); //değişkenin tıklanma olayına dinleyici ekleyerek fonksiyon çağırıldı.
          ogrenci2Button.onClick.AddListener(ogrenci2BilgisiniYazdir);
          ogrenci3Button.onClick.AddListener(ogrenci3BilgisiniYazdir);

      }


      private void ogrenciBilgisiniYazdir()
      {
          ders1_Text.text = "Biyoloji";
          ders2_Text.text = "Kimya";
          ders3_Text.text = "Fizik";
          ders4_Text.text = "Türk Edebiyatı";
          ders5_Text.text = "Matematik I";

      }
      private void ogrenci2BilgisiniYazdir()
      {

          ders1_Text.text = "Beden Eğitimi";
          ders2_Text.text = "Dil ve Anlatım";
          ders3_Text.text = "Din Kültürü ve Ahlak Bilgisi";
          ders4_Text.text = "Müzik";
          ders5_Text.text = "Seçmeli Gitar";
      }
      private void ogrenci3BilgisiniYazdir()
      {
          ders1_Text.text = "Tarih";
          ders2_Text.text = "Coğrafya";
          ders3_Text.text = "Fizik II";
          ders4_Text.text = "Matematik II";
          ders5_Text.text = "Kimya II";
      }
}




