﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class hafta03ui_manager : MonoBehaviour {

    public Text goruntuleyiciText;
    public Button gonderButton;
    public InputField adGirisi_InputField;
    private void Start()
    {
        gonderButton.onClick.AddListener(BilgileriGonder);
    }
    private void BilgileriGonder()
    {
        string adGirdisi= adGirisi_InputField.text;
        goruntuleyiciText.text = adGirdisi;


    }
}
