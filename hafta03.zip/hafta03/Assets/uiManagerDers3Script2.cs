﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class uiManagerDers3Script2 : MonoBehaviour {

    public InputField adInputField, soyadInputField, yasInputField, meslekInputField, adresInputField;
    public Button gonderbutton, onayButton;
    public Text adText, soyadText, yasText, meslekText, adresText;
    public Transform bilgiKontrolPanel;

    public List<string> programVerileri = new List<string>();

    public void Start()
    {
        bilgiKontrolPanel.gameObject.SetActive(false);
    }

    public void BilgileriGonder() {

        bilgiKontrolPanel.gameObject.SetActive(true);
        adText.text = adInputField.text;
        soyadText.text = soyadInputField.text;
        yasText.text = yasInputField.text;
        meslekText.text = meslekInputField.text;
        adresText.text = adresInputField.text;
    }

    public void OnaylanmisBilgileriKaydet() {

        programVerileri.Add(adText.text);
        programVerileri.Add(soyadText.text);
        programVerileri.Add(yasText.text);
        programVerileri.Add(meslekText.text);
        programVerileri.Add(adresText.text);
       
        /*
         Ödev; böyle bir ortamda chat uygulaması ya da günlük uygulaması olacak. ekranın altında bir adet boydan 
         genişletilmiş bir inputfield eklenecek. 
         * bu inputfieldin altında bir adet gönder butonu olacak.
         * gönder butonunun hizasında sağa dayalı bir kaydet butonu olacak gonder butonunun hizasında 
         * sola dayalı sıfırla butonu olacak. 
         * ekranın arada geri kalanı bir **text objesi olacak bunun içinde paragraflarca yazı görüntüleyeceğiz.
         * gönder butonuna tıklandığında inputfield içindeki texti **text objesinin içine ekleyecek ama önceki
         * girilen text varsa onu silmeyecek. üzerine devam edecek.
         * gonder butonuna bastığımızda **text objesinin tüm metnini bir listeye ekleyecek
         * sıfırla butonuna bastığımızda **text objesinin tüm metni silinecek
         */
    
    }
}
