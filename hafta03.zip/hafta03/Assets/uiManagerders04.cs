﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class uiManagerders04 : MonoBehaviour {
    public InputField adInputField, soyadInputField, yasInputField, meslekInputField, adresInputField, kayitNo_InputField ;
    public Button gonderbutton, onayButton, kayitYuklemeButonu_Button, kaydetButonu_Button, yukleButonu_Button;
    public Text adText, soyadText, yasText, meslekText, adresText;
    public Transform bilgiKontrolPanel;

    public List<DataUnit> programVerileri = new List<DataUnit>();

    public void Start()
    {
        onayButton.onClick.AddListener(OnaylanmisBilgileriKaydet);
        gonderbutton.onClick.AddListener(BilgileriGonder);
        kayitYuklemeButonu_Button.onClick.AddListener(BilgileriYukle);
        kaydetButonu_Button.onClick.AddListener(VerileriDiskeKaydet);
        yukleButonu_Button.onClick.AddListener(VerileriDisktenGeriYukle);
        //bilgiKontrolPanel.gameObject.SetActive(false);
    }

    private void BilgileriYukle()
    {
        int kayitNo= int.Parse(kayitNo_InputField.text) - 1;
        adText.text=programVerileri[kayitNo].ad;
        soyadText.text=programVerileri[kayitNo].soyad;
        yasText.text=programVerileri[kayitNo].yas;
        meslekText.text= programVerileri[kayitNo].meslek;
        adresText.text=  programVerileri[kayitNo].adres;
       
    }

    private void VerileriDisktenGeriYukle()
    {
        GetComponent<DataManager>().Load();
    }
    private void VerileriDiskeKaydet()
    {
        GetComponent<DataManager>().Save();
    }
    private void BilgileriGonder()
    {

        //bilgiKontrolPanel.gameObject.SetActive(true);
        adText.text = adInputField.text;
        soyadText.text = soyadInputField.text;
        yasText.text = yasInputField.text;
        meslekText.text = meslekInputField.text;
        adresText.text = adresInputField.text;
    }

    private void OnaylanmisBilgileriKaydet()
    {
        DataUnit yeniVeriGirisi=new DataUnit();
        yeniVeriGirisi.ad=adText.text;
        yeniVeriGirisi.soyad=soyadText.text;
        yeniVeriGirisi.yas=yasText.text;
        yeniVeriGirisi.meslek=meslekText.text;
        yeniVeriGirisi.adres=adresText.text;
        programVerileri.Add(yeniVeriGirisi);
        
     }
}
